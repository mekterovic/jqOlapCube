﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using log4net;
using Microsoft.AnalysisServices.AdomdClient;
using Newtonsoft.Json;

namespace OlapService.Controllers
{
    public class RepositoryController : Controller {


       [Route("save")]
       [HttpPost]
       public ActionResult Save(string cubeName, string levelName, string sessionId) {
          
          // TODO: Actually save :)
          
          var jsonMsg = new {
             Status = "OK",
             Message = "Query saved."
          };

          var jsonResult = Json(jsonMsg, JsonRequestBehavior.DenyGet);
          
          return jsonResult;
       }
    }
}
