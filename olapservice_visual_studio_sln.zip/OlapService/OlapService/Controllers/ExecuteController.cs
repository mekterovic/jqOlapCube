﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using log4net;
using Microsoft.AnalysisServices.AdomdClient;
using Newtonsoft.Json;


namespace OlapService.Controllers
{
    public class ExecuteController : Controller
    {
       protected static readonly ILog log = LogManager.GetLogger(typeof(ExecuteController));

       [Route("execute")]
       [HttpPost]
       public ActionResult Execute(string mdx, string sessionId) {
          try {

             AdomdConnection olapConn = null;


             try {
                olapConn = new AdomdConnection(ConfigurationManager.ConnectionStrings["OLAPConnectionString"].ConnectionString);
                olapConn.Open();

                // Create the object AdomdCommand.
                AdomdCommand command = new AdomdCommand();
                command.Connection = olapConn;                                
                
                command.CommandText = mdx;
               
                CellSet result = command.ExecuteCellSet();
                
                var axis = from Axis a in result.Axes
                           select new {
                              axisName = a.Name,
                              hierarchies = (from Hierarchy h in a.Set.Hierarchies
                                             select new {
                                                uname = h.UniqueName,
                                                caption    = h.Caption
                                             }).ToArray(),
                              positions = (from Position p in a.Positions
                                           select new {
                                              ordinal = p.Ordinal,
                                              members = (from Member m in p.Members
                                                                 select new {
                                                                    uname = m.UniqueName,
                                                                    //name = m.Name,
                                                                    leveldepth = m.LevelDepth,
                                                                    //levelName = m.LevelName,
                                                                    caption = m.Caption
                                                                 }).ToArray()
                                           }).ToArray()

                           };
                var cells = from Cell c in result.Cells
                            select new {
                               value = c.Value,
                               formattedValue = c.FormattedValue
                            };
                

                var jsonMsg = new {
                   Status = "OK",
                   axisInfo = axis.ToArray(),
                   cSet     = cells.ToArray()
                };

                olapConn.Close();

                //return Json(jsonMsg, JsonRequestBehavior.AllowGet);
                var jsonResult = Json(jsonMsg, JsonRequestBehavior.DenyGet);
                jsonResult.MaxJsonLength = int.MaxValue;
                return jsonResult;

             } catch (Exception e) {

                throw new LoggedWebAppException("Error (sessId=" + sessionId + ") executing query:\n" + mdx, e);

             } finally {

                //if (olapConn != null && olapConn.State == ConnectionState.Open) olapConn.Close();
             }

             //}  //  using...


          } catch (Exception exc) {
             return Json(new { Status = "Error", Message = exc.InnerException.Message, Mdx = mdx }, JsonRequestBehavior.AllowGet);
          }
       }

       private static char CSV_SEPARATOR = ';';

       [Route("getcsv")]
       [HttpPost]
       public FileContentResult getCsv(string mdx, string sessionId) {
          try {

             AdomdConnection olapConn = null;


             try {
                olapConn = new AdomdConnection(ConfigurationManager.ConnectionStrings["OLAPConnectionString"].ConnectionString);
                olapConn.Open();
                
                AdomdCommand command = new AdomdCommand();
                command.Connection = olapConn;

                command.CommandText = mdx;

                CellSet result = command.ExecuteCellSet();

                StringBuilder sb = new StringBuilder();

                
                int i = 0;
                foreach (Hierarchy hCol in result.Axes[0].Set.Hierarchies) {
                   if (i < result.Axes[0].Set.Hierarchies.Count - 1) {
                      for (int e = 0; e < result.Axes[1].Set.Hierarchies.Count; ++e ) {                         
                         sb.Append(CSV_SEPARATOR);
                      }
                   } else {
                      foreach (Hierarchy hRow in result.Axes[1].Set.Hierarchies) {
                         sb.Append(hRow.Caption);
                         sb.Append(CSV_SEPARATOR);
                      }
                   }
                   foreach (Position p in result.Axes[0].Positions) {
                      sb.Append(p.Members[i].Caption);
                      sb.Append(CSV_SEPARATOR);
                   }
                   ++i;
                   sb.Append(Environment.NewLine);
                }
                int row = 0;
                foreach (Position p in result.Axes[1].Positions) {
                   foreach (Member m in p.Members) {
                      sb.Append(m.Caption);
                      sb.Append(CSV_SEPARATOR);
                   }
                   for (int col = 0; col < result.Axes[0].Positions.Count; ++col) {
                      sb.Append(result.Cells[row * result.Axes[0].Positions.Count + col].FormattedValue);  // ili value? pitanje je sad!
                      sb.Append(CSV_SEPARATOR);                      
                   }
                   row++;
                   sb.Append(Environment.NewLine);
                   
                }
                

                olapConn.Close();

                return File(new System.Text.UTF8Encoding().GetBytes(sb.ToString()),
                           "text/csv",
                           string.Format("Report-UserName-{0:yyyy-MM-dd_hh-mm-ss-tt}.csv", DateTime.Now)
                           );

             } catch (Exception e) {

                throw new LoggedWebAppException("Error (sessId=" + sessionId + ") executing query:\n" + mdx, e);

             } 


          } catch {
             return null;
          }
       }



       

    }
}
