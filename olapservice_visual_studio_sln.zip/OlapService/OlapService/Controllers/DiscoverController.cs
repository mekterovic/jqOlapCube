﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AnalysisServices.AdomdClient;
using Newtonsoft.Json;



namespace OlapService.Controllers {
   public class DiscoverController : Controller {

      private static int MAX_MEMBER_COUNT = 1000;



      [Route("levelmembers")]
      [HttpGet]
      //[AjaxOnly]
      //[Authorize]
      public ActionResult LevelMembers(string cubeName, string levelName, string sessionId) {

         try {

            AdomdConnection olapConn = null;


            try {
               olapConn = new AdomdConnection(ConfigurationManager.ConnectionStrings["OLAPConnectionString"].ConnectionString);
               olapConn.Open();

               string[] args = levelName.Replace("[", "").Replace("]", "").Split('.');

               Level lvl = olapConn.Cubes[cubeName.Replace("[", "").Replace("]", "")]
                                   .Dimensions[args[0]]
                                   .Hierarchies[args[1]]
                                   .Levels[args[2]];


               var members = from Member m in lvl.GetMembers(0, MAX_MEMBER_COUNT)

                             select new {
                                uname = m.UniqueName,
                                huname = "[" + args[0] + "].[" + args[1] + "]",
                                caption = m.Caption,
                                etype = "Member"
                             };


               var jsonData = new {
                  Status = "OK",
                  Members = members.ToArray()
               };


               return Json(jsonData, JsonRequestBehavior.AllowGet);


            } catch (Exception e) {

               throw new LoggedWebAppException("Error retrieving level memebers for cube: " + cubeName + " and level:" + levelName, e);

            } finally {
            }

         } catch (Exception exc) {
            return Json(new { Status = "Err", Message = exc.Message }, JsonRequestBehavior.AllowGet);
         }
      }


      [Route("metadata")]
      [HttpGet]
      //[AjaxOnly]
      //[Authorize]
      public ActionResult MetaData(string cubeName, string sessionId) {
         try {

            AdomdConnection olapConn = null;


            try {
               olapConn = new AdomdConnection(ConfigurationManager.ConnectionStrings["OLAPConnectionString"].ConnectionString);
               olapConn.Open();

               CubeDef cube = olapConn.Cubes[cubeName];

               //{
               //  "data" : "node_title",
               //  // omit `attr` if not needed; the `attr` object gets passed to the jQuery `attr` function
               //  "attr" : { "id" : "node_identificator", "some-other-attribute" : "attribute_value" },
               //  // `state` and `children` are only used for NON-leaf nodes
               //  "state" : "closed", // or "open", defaults to "closed"
               //  "children" : [ /* an array of child nodes objects */ ]
               //}
               var measures = from Measure m in cube.Measures
                              select new {
                                 data = m.Caption,
                                 attr = new { uname = m.UniqueName, etype = "Measure", DisplayFolder = (m.Properties["MEASUREGROUP_NAME"] != null && m.Properties["MEASUREGROUP_NAME"].Value != null) ? m.Properties["MEASUREGROUP_NAME"].Value.ToString() : "", huname = "[Measures]", caption = m.Caption },      // ovo su glupo napravili
                              };
               var measureNode = new {
                  data = "Measures",
                  attr = new { uname = "[Measures]", etype = "Dimension", huname = "[Measures]", caption = "Measures" },
                  children = measures.OrderBy(x => x.attr.DisplayFolder).ThenBy(x => x.data).ToArray() // 
               };
               var dims = from Dimension d in cube.Dimensions
                          where !d.Name.Equals("Measures")
                          select new {
                             data = d.Caption,
                             attr = new { uname = d.UniqueName, etype = "Dimension", huname = d.UniqueName, caption = d.Caption },
                             children = (from Hierarchy h in cube.Dimensions[d.Name].Hierarchies
                                         select new {
                                            data = h.Caption,
                                            attr = new { uname = h.UniqueName, DisplayFolder = h.DisplayFolder, etype = "Hierarchy", huname = h.UniqueName, caption = h.Caption },
                                            children = (from Level l in cube.Dimensions[d.Name].Hierarchies[h.Name].Levels
                                                        select new {
                                                           data = l.Caption,
                                                           attr = new { uname = l.UniqueName, etype = "Level", huname = l.ParentHierarchy.UniqueName, levelnumber = l.LevelNumber, caption = l.Caption }  // dUName = l.ParentHierarchy.ParentDimension.UniqueName,
                                                        }).ToArray()
                                         }).OrderBy(hh => hh.attr.DisplayFolder).ThenBy(hh => hh.data).ToArray()
                          };

               

               var jsonData = new {
                  Status = "OK",
                  Dimensions = (new Object[] { measureNode }).Concat(dims).ToArray()
               };


               return Json(jsonData, JsonRequestBehavior.AllowGet);


            } catch (Exception e) {

                throw new LoggedWebAppException("Error retrieving metadata for cube:" + cubeName, e);

            } finally {

               //if (olapConn != null && olapConn.State == ConnectionState.Open) olapConn.Close();
            }

           


         } catch (Exception exc) {
            return Json(new { Status = "Err", Message = exc.Message + "\nInner:" + exc.InnerException.Message }, JsonRequestBehavior.AllowGet);
         }
      }


   }
}
