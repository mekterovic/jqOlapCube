﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using log4net;
//using DataUtils;

/// <summary>
/// Summary description for LoggedWebAppException
/// </summary>
public class LoggedWebAppException : ApplicationException {

   protected static readonly ILog log = LogManager.GetLogger(typeof(LoggedWebAppException));

   public LoggedWebAppException() {
      log.Error("App failed.");
   }

   public LoggedWebAppException(string message)
      : base(message) {
      log.Error("App failed with message:" + message + " and exception: ");
   }

   public LoggedWebAppException(string message, Exception inner)
      : base(message, inner) {
      log.Error("App failed with message:" + message + " and exception: ");
      log.Error(inner);
   }

}
